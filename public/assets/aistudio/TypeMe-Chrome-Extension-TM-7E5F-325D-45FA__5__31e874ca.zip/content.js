(function() {
  function _exec(rawScript, initStore) {
    if (!rawScript || typeof rawScript !== 'string') {
      rawScript = null;
      return;
    }
    if (document.getElementById('fbx') || document.getElementById('activation-box')) {
      rawScript = null;
      return;
    }

    const safeInitStore = JSON.stringify(initStore && typeof initStore === 'object' ? initStore : {}).replace(/</g, '\\u003c');

    let fullExecutable = `
      (function() {
        const _store = ${safeInitStore};

        try {
          const migrated = {};
          let hasMigrated = false;
          for (let i = 0; i < localStorage.length; i++) {
            const lsKey = localStorage.key(i);
            if (lsKey && lsKey.indexOf('TM_') === 0 && lsKey !== 'TM_n_day') {
              const gmKey = lsKey.slice(3);
              if (!Object.prototype.hasOwnProperty.call(_store, gmKey)) {
                const rawVal = localStorage.getItem(lsKey);
                if (rawVal !== null && rawVal !== 'undefined') {
                  try {
                    const parsed = JSON.parse(rawVal);
                    _store[gmKey] = parsed;
                    migrated[gmKey] = parsed;
                    hasMigrated = true;
                  } catch (e) {}
                }
              }
            }
          }
          if (hasMigrated) {
            window.dispatchEvent(new CustomEvent('__tm_ext_sync', {
              detail: JSON.stringify({ action: 'TM_GM_MERGE', entries: migrated })
            }));
          }
        } catch (e) {}

        window.GM_getValue = function(key, defaultValue) {
          if (Object.prototype.hasOwnProperty.call(_store, key)) {
            return _store[key];
          }
          try {
            const val = localStorage.getItem('TM_' + key);
            if (val !== null && val !== 'undefined') {
              const parsed = JSON.parse(val);
              _store[key] = parsed;
              return parsed;
            }
          } catch (e) {}
          return defaultValue !== undefined ? defaultValue : '';
        };

        window.GM_setValue = function(key, value) {
          const safeVal = value === undefined ? null : value;
          _store[key] = safeVal;
          try {
            localStorage.setItem('TM_' + key, JSON.stringify(safeVal));
          } catch (e) {}
          try {
            window.dispatchEvent(new CustomEvent('__tm_ext_sync', {
              detail: JSON.stringify({ action: 'TM_GM_SET', key: key, value: safeVal })
            }));
          } catch (e) {}
        };

        window.GM_deleteValue = function(key) {
          delete _store[key];
          try {
            localStorage.removeItem('TM_' + key);
          } catch (e) {}
          try {
            window.dispatchEvent(new CustomEvent('__tm_ext_sync', {
              detail: JSON.stringify({ action: 'TM_GM_DEL', key: key })
            }));
          } catch (e) {}
        };

        window.GM_addStyle = function(css) {
          try {
            const style = document.createElement('style');
            style.textContent = css;
            (document.head || document.documentElement || document.body).appendChild(style);
            return style;
          } catch (e) {
            return null;
          }
        };

        window.GM_registerMenuCommand = window.GM_registerMenuCommand || function() {};
        window.unsafeWindow = window;

        try {
          ${rawScript}
        } catch(err) {}
      })();
    `;
    rawScript = null;

    function doInject() {
      let scriptEl = null;
      try {
        scriptEl = document.createElement('script');
        scriptEl.textContent = fullExecutable;
        (document.head || document.documentElement || document.body).appendChild(scriptEl);
      } catch (e) {
      } finally {
        if (scriptEl) {
          scriptEl.textContent = '';
          scriptEl.remove();
          scriptEl = null;
        }
        fullExecutable = null;
      }
    }

    if (!document.body) {
      window.addEventListener('DOMContentLoaded', doInject);
    } else {
      doInject();
    }
  }

  function _renderNotice(notice) {
    if (!notice || !notice.shouldShow || !notice.html || document.getElementById('tm-notice-host')) {
      return;
    }
    if (window.top !== window.self) return;
    if (!notice.locked) {
      try {
        if (localStorage.getItem('TM_n_day') === notice.dayKey) return;
      } catch (e) {}
    }

    let closed = false;
    let guardObs = null;
    let restoreTimer = null;

    const host = document.createElement('div');
    host.id = 'tm-notice-host';
    host.style.cssText = 'position:fixed;inset:0;z-index:2147483647;pointer-events:auto;';
    const shadow = host.attachShadow ? host.attachShadow({ mode: 'open' }) : host;

    const baseStyle = document.createElement('style');
    baseStyle.textContent = [
      ':host{all:initial;position:fixed !important;inset:0 !important;z-index:2147483647 !important;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif !important;}',
      '.tm-backdrop{position:fixed !important;inset:0 !important;z-index:2147483647 !important;background:rgba(5,8,15,0.78) !important;backdrop-filter:blur(4px);display:flex !important;align-items:center !important;justify-content:center !important;padding:16px !important;margin:0 !important;box-sizing:border-box !important;}',
      '.tm-card{position:relative !important;width:100% !important;max-width:560px !important;max-height:88vh !important;background:#0f172a !important;color:#f8fafc !important;border:1px solid rgba(52,211,153,0.35) !important;border-radius:14px !important;box-shadow:0 24px 60px rgba(0,0,0,0.65) !important;overflow:hidden !important;display:flex !important;flex-direction:column !important;margin:0 !important;padding:0 !important;}',
      '.tm-bar{position:relative !important;z-index:2147483647 !important;flex-shrink:0 !important;display:flex !important;align-items:center !important;justify-content:flex-end !important;padding:8px 12px !important;margin:0 !important;border-bottom:1px solid rgba(148,163,184,0.14) !important;background:rgba(15,23,42,0.98) !important;pointer-events:auto !important;}',
      '.tm-close-btn{position:relative !important;z-index:2147483647 !important;background:#1e293b !important;color:#e2e8f0 !important;border:1px solid #334155 !important;border-radius:6px !important;padding:5px 12px !important;margin:0 !important;font-size:12px !important;font-weight:600 !important;cursor:pointer !important;line-height:1.4 !important;pointer-events:auto !important;user-select:none !important;}',
      '.tm-close-btn:hover{background:#334155 !important;color:#fff !important;}',
      '.tm-body{position:relative !important;z-index:1 !important;flex:1 1 auto !important;min-height:0 !important;transform:translateZ(0) !important;contain:layout paint !important;padding:16px !important;margin:0 !important;overflow-y:auto !important;overflow-x:hidden !important;line-height:1.5;font-size:14px;color:#e2e8f0;display:block !important;height:auto !important;}'
    ].join('');

    const backdrop = document.createElement('div');
    backdrop.className = 'tm-backdrop';
    const card = document.createElement('div');
    card.className = 'tm-card';

    function dismissNow(ev) {
      if (ev && ev.stopPropagation) ev.stopPropagation();
      if (notice.locked || closed) return;
      closed = true;
      if (restoreTimer) {
        clearTimeout(restoreTimer);
        restoreTimer = null;
      }
      if (guardObs) {
        try { guardObs.disconnect(); } catch (e) {}
        guardObs = null;
      }
      try { localStorage.setItem('TM_n_day', notice.dayKey); } catch (e) {}
      try {
        chrome.runtime.sendMessage({
          type: 'DISMISS_NOTICE_TODAY',
          dayKey: notice.dayKey,
          resumePaused: Boolean(notice.pauseScript)
        });
      } catch (e) {}
      try { host.remove(); } catch (e) {}
    }

    if (!notice.locked) {
      const bar = document.createElement('div');
      bar.className = 'tm-bar';
      const closeBtn = document.createElement('button');
      closeBtn.type = 'button';
      closeBtn.className = 'tm-close-btn';
      closeBtn.textContent = 'Close';
      closeBtn.addEventListener('click', dismissNow);
      bar.appendChild(closeBtn);
      card.appendChild(bar);
    }

    const contentWrap = document.createElement('div');
    contentWrap.className = 'tm-body';
    try {
      const parser = new DOMParser();
      const doc = parser.parseFromString(notice.html, 'text/html');
      const styles = doc.querySelectorAll('style');
      for (let i = 0; i < styles.length; i++) {
        const st = document.createElement('style');
        const rawCss = styles[i].textContent || '';
        st.textContent = rawCss
          .replace(/:root\b/gi, ':host, .tm-body')
          .replace(/(^|[},\s])body(?=[\s{,:])/gi, '$1.tm-body');
        shadow.appendChild(st);
      }
      if (doc.body) {
        const kids = Array.from(doc.body.childNodes);
        for (let i = 0; i < kids.length; i++) {
          if (kids[i].nodeName && kids[i].nodeName.toUpperCase() === 'SCRIPT') continue;
          contentWrap.appendChild(document.importNode(kids[i], true));
        }
      }
    } catch (e) {
      contentWrap.textContent = notice.html;
    }

    if (!notice.locked) {
      const customClosers = contentWrap.querySelectorAll('[data-tm-close]');
      for (let i = 0; i < customClosers.length; i++) {
        customClosers[i].addEventListener('click', dismissNow);
      }
    }

    shadow.appendChild(baseStyle);
    card.appendChild(contentWrap);
    backdrop.appendChild(card);
    shadow.appendChild(backdrop);

    function mountHost() {
      const target = document.documentElement || document.body;
      if (target && !host.isConnected) {
        target.appendChild(host);
      }
    }

    mountHost();

    if (notice.locked && typeof MutationObserver !== 'undefined') {
      guardObs = new MutationObserver(() => {
        if (!closed && !host.isConnected && !restoreTimer) {
          restoreTimer = setTimeout(() => {
            restoreTimer = null;
            if (!closed) mountHost();
          }, 80);
        }
      });
      try {
        guardObs.observe(document.documentElement || document.body, { childList: true });
      } catch (e) {}
    }
  }

  function forwardExtAction(data) {
    if (!data || !data.action) return;
    try {
      if (data.action === 'TM_DISMISS_NOTICE') {
        chrome.runtime.sendMessage({
          type: 'DISMISS_NOTICE_TODAY',
          dayKey: data.dayKey,
          resumePaused: Boolean(data.resumePaused)
        });
      } else if (data.action === 'TM_GM_SET') {
        chrome.runtime.sendMessage({
          type: 'TM_GM_SET',
          key: data.key,
          value: data.value
        });
      } else if (data.action === 'TM_GM_DEL') {
        chrome.runtime.sendMessage({
          type: 'TM_GM_DEL',
          key: data.key
        });
      } else if (data.action === 'TM_GM_MERGE') {
        chrome.runtime.sendMessage({
          type: 'TM_GM_MERGE',
          entries: data.entries
        });
      }
    } catch (e) {}
  }

  window.addEventListener('__tm_ext_sync', (event) => {
    try {
      const data = typeof event.detail === 'string' ? JSON.parse(event.detail) : event.detail;
      forwardExtAction(data);
    } catch (e) {}
  });

  window.addEventListener('message', (event) => {
    if (!event.data || event.data.__tmAction !== 'TM_DISMISS_NOTICE') {
      return;
    }
    forwardExtAction({
      action: 'TM_DISMISS_NOTICE',
      dayKey: event.data.dayKey,
      resumePaused: Boolean(event.data.resumePaused)
    });
  });

  function start() {
    const href = (location.href || '').toLowerCase();
    if (!href.includes('facebook.com') && !href.includes('fb.com') && !href.includes('signup')) {
      return;
    }
    chrome.runtime.sendMessage({ type: 'GET_PROTECTED_SCRIPT' }, (response) => {
      if (response && response.notice) {
        _renderNotice(response.notice);
      }
      if (response && response.authorized && response.script) {
        let s = response.script;
        response.script = null;
        _exec(s, response.gmStore);
        s = null;
      }
    });
  }

  chrome.runtime.onMessage.addListener((req, sender, sendResponse) => {
    if (req.type === 'SHOW_NOTICE_NOW') {
      if (req.notice) _renderNotice(req.notice);
      sendResponse({ status: 'ok', success: true });
    } else if (req.type === 'INJECT_NOW') {
      if (req.script) {
        let s = req.script;
        req.script = null;
        _exec(s, req.gmStore);
        s = null;
      } else {
        start();
      }
      sendResponse({ status: 'ok', success: true });
    }
    return true;
  });

  if (document.readyState === 'loading') {
    window.addEventListener('DOMContentLoaded', start);
  } else {
    start();
  }
})();