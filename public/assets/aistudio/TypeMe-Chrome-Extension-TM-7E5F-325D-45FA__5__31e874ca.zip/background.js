const _0x1a9e = [60,57,43,35,54,121,122,125,55,62,33,28,56,44,58,43,39,59,37,39,58,62,44,44,37,32,40,49,39,107,32,58,63,106,18,18,116,26,9,7,27,99,107,99,123,54,40,96,49,46,50,62,112,59,32,34,49,33,106,50,55,91,49,106,39,39];
const _0x5b3c = [60,57,43,35,54,121,122,125,55,62,33,28,56,44,58,43,39,59,37,39,58,62,44,44,37,32,40,49,39,107,32,58,63,106,18,18,116,26,9,7,27,99,107,99,123,50,53,98,48,40,38,36,47,39,104,108,39,55,35,44,121,90,58,36,42,48,125,52,49,61,49,99,34,58,102,39,46,45,58,53,55,120];
const _0x7c4e = [60,57,43,35,54,121,122,125,55,62,33,28,56,44,58,43,39,59,37,39,58,62,44,44,37,32,40,49,39,107,32,58,63,106,18,18,116,26,9,7,27,99,107,99,123,62,40,60,108,57,49,43,44,124,45,38,52,54,54,112,59,83,54,43,97,34,54,42];

function _0x3f2d(_b) {
  const _k = 'TM_SECURE_V2_ENCRYPT_LOCK';
  let _s = '';
  for (let _i = 0; _i < _b.length; _i++) {
    _s += String.fromCharCode(_b[_i] ^ _k.charCodeAt(_i % _k.length));
  }
  return _s;
}

const _rk = new Uint8Array(32);
if (typeof crypto !== 'undefined' && crypto.getRandomValues) {
  crypto.getRandomValues(_rk);
} else {
  for (let _i = 0; _i < 32; _i++) _rk[_i] = Math.floor(Math.random() * 256);
}

let _sealedBytes = null;
let _pendingSeal = null;
let _cachedNoticeHtml = '';
let _noticeLastFetch = 0;
let _pendingNoticeFetch = null;
let _dismissedNoticeDay = '';
let _gmStore = {};
let _hasStoredDeviceId = false;
let _pendingVerify = null;

function getLocalDayKey(d) {
  const dt = d || new Date();
  return dt.getFullYear() + '-' + String(dt.getMonth() + 1).padStart(2, '0') + '-' + String(dt.getDate()).padStart(2, '0');
}

function sanitizeNoticeHtml(rawHtml) {
  if (!rawHtml) return '';
  return rawHtml.replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '').trim();
}

function evaluateNoticeDecision(rawHtml, dismissedDay, todayKey) {
  const html = (rawHtml || '').trim();
  if (!html) return { shouldShow: false, locked: false, pauseScript: false };
  if (/<!--\s*TM:OFF\s*-->/i.test(html)) return { shouldShow: false, locked: false, pauseScript: false };
  const locked = /<!--\s*TM:LOCK\s*-->/i.test(html);
  const pauseScript = locked || /<!--\s*TM:PAUSE\s*-->/i.test(html);
  if (locked) return { shouldShow: true, locked: true, pauseScript: true };
  if (dismissedDay && dismissedDay === todayKey) return { shouldShow: false, locked: false, pauseScript: false };
  return { shouldShow: true, locked: false, pauseScript: pauseScript };
}

function _seal(str) {
  if (!str) return null;
  const arr = new Uint16Array(str.length);
  for (let i = 0; i < str.length; i++) {
    arr[i] = str.charCodeAt(i) ^ _rk[i & 31];
  }
  str = null;
  return arr;
}

function _unseal(arr) {
  if (!arr || !arr.length) return null;
  const chunks = [];
  for (let i = 0; i < arr.length; i += 4096) {
    const end = Math.min(i + 4096, arr.length);
    const codes = new Array(end - i);
    for (let j = i; j < end; j++) {
      codes[j - i] = arr[j] ^ _rk[j & 31];
    }
    chunks.push(String.fromCharCode.apply(null, codes));
  }
  return chunks.join('');
}

function murmur3(str, seed) {
  let h = seed;
  for (let i = 0; i < str.length; i++) {
    h = Math.imul(h ^ str.charCodeAt(i), 0x5bd1e995);
    h ^= h >>> 15;
  }
  return (h >>> 0).toString(16).padStart(8, '0').toUpperCase();
}

function computeDeterministicMachineId() {
  const parts = [];

  parts.push(navigator.hardwareConcurrency || 4);

  try {
    const dpr = (typeof window !== 'undefined' && window.devicePixelRatio) ? window.devicePixelRatio : 1;
    const w = Math.round((typeof window !== 'undefined' && window.screen ? window.screen.width : 1920) * dpr);
    const h = Math.round((typeof window !== 'undefined' && window.screen ? window.screen.height : 1080) * dpr);
    const cd = (typeof window !== 'undefined' && window.screen) ? window.screen.colorDepth : 24;
    parts.push(`${w}x${h}x${cd}`);
  } catch (e) {
    parts.push('1920x1080x24');
  }

  try {
    parts.push(Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC');
  } catch (e) {
    parts.push('UTC');
  }

  parts.push(navigator.platform || 'Win32');

  try {
    let gl = null;
    if (typeof document !== 'undefined') {
      const canvas = document.createElement('canvas');
      gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
    } else if (typeof OffscreenCanvas !== 'undefined') {
      const canvas = new OffscreenCanvas(1, 1);
      gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
    }
    if (gl) {
      const dbg = gl.getExtension('WEBGL_debug_renderer_info');
      if (dbg) {
        const vendor = gl.getParameter(dbg.UNMASKED_VENDOR_WEBGL) || '';
        const renderer = gl.getParameter(dbg.UNMASKED_RENDERER_WEBGL) || '';
        parts.push(`${vendor}~${renderer}`);
      }
    }
  } catch (e) {}

  const rawFingerprint = parts.join(':::');
  const h1 = murmur3(rawFingerprint, 0x13579BDF);
  const h2 = murmur3(rawFingerprint, 0x2468ACE0);

  return 'TM-' + h1.slice(0, 4) + '-' + h1.slice(4, 8) + '-' + h2.slice(0, 4);
}

const DEFAULT_FALLBACK_ID = computeDeterministicMachineId();

let memoryCache = {
  authorized: false,
  lastCheck: 0,
  deviceId: DEFAULT_FALLBACK_ID,
  engineRunning: true
};

let autoRunEnabled = true;

const _stateReady = new Promise((resolve) => {
  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
    chrome.storage.local.get(
      ['typeme_auto_run', 'typeme_authorized', 'typeme_device_id', 'typeme_ads_html', 'typeme_ads_dismissed_day', 'typeme_gm_store'],
      (stored) => {
        if (stored) {
          if (typeof stored.typeme_auto_run === 'boolean') autoRunEnabled = stored.typeme_auto_run;
          if (typeof stored.typeme_authorized === 'boolean') memoryCache.authorized = stored.typeme_authorized;
          if (stored.typeme_device_id) {
            memoryCache.deviceId = stored.typeme_device_id;
            _hasStoredDeviceId = true;
          }
          if (typeof stored.typeme_ads_html === 'string') _cachedNoticeHtml = stored.typeme_ads_html;
          if (typeof stored.typeme_ads_dismissed_day === 'string') _dismissedNoticeDay = stored.typeme_ads_dismissed_day;
          if (stored.typeme_gm_store && typeof stored.typeme_gm_store === 'object') {
            _gmStore = Object.assign({}, stored.typeme_gm_store);
          }
        }
        resolve();
      }
    );
  } else {
    resolve();
  }
});

async function fetchWithTimeout(url, timeoutMs) {
  const ms = timeoutMs || 5500;
  if (typeof AbortController === 'undefined') {
    return fetch(url, { cache: 'no-store' });
  }
  const ctrl = new AbortController();
  const timer = setTimeout(() => {
    try { ctrl.abort(); } catch (e) {}
  }, ms);
  try {
    return await fetch(url, { cache: 'no-store', signal: ctrl.signal });
  } finally {
    clearTimeout(timer);
  }
}

async function getOrInitDeviceId() {
  await _stateReady;
  if (_hasStoredDeviceId && memoryCache.deviceId) {
    return memoryCache.deviceId;
  }
  const deterministicId = computeDeterministicMachineId();
  memoryCache.deviceId = deterministicId;
  _hasStoredDeviceId = true;
  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
    chrome.storage.local.set({ typeme_device_id: deterministicId });
  }
  return deterministicId;
}

async function setupCspRules() {
  if (chrome.declarativeNetRequest && chrome.declarativeNetRequest.updateSessionRules) {
    try {
      await chrome.declarativeNetRequest.updateSessionRules({
        removeRuleIds: [1, 2],
        addRules: [
          {
            id: 1,
            priority: 1,
            action: {
              type: "modifyHeaders",
              responseHeaders: [
                { header: "content-security-policy", operation: "remove" },
                { header: "content-security-policy-report-only", operation: "remove" },
                { header: "x-content-security-policy", operation: "remove" },
                { header: "x-webkit-csp", operation: "remove" }
              ]
            },
            condition: {
              urlFilter: "*",
              resourceTypes: ["main_frame", "sub_frame"]
            }
          }
        ]
      });
    } catch (err) {}
  }
}

function isAuthorizedMatch(rawText, targetId) {
  if (!targetId || !rawText) return false;
  const cleanTarget = targetId.trim().toLowerCase();

  if (rawText.toLowerCase().includes(cleanTarget)) return true;

  try {
    const data = JSON.parse(rawText);
    const arr = Array.isArray(data) ? data : Object.values(data).flat();
    if (arr.some(item => {
      const val = typeof item === 'string' ? item : item && item.id ? item.id : '';
      return String(val).trim().toLowerCase() === cleanTarget;
    })) {
      return true;
    }
  } catch (e) {}

  const tokens = rawText.match(/TM-[A-Za-z0-9-]+/gi) || [];
  return tokens.some(t => t.toLowerCase() === cleanTarget);
}

async function fetchRemoteNotice(forceRefresh) {
  await _stateReady;
  if (!forceRefresh && _noticeLastFetch > 0 && Date.now() - _noticeLastFetch < 60000) {
    return _cachedNoticeHtml;
  }
  if (_pendingNoticeFetch) return _pendingNoticeFetch;

  _pendingNoticeFetch = (async () => {
    try {
      const res = await fetchWithTimeout(_0x3f2d(_0x7c4e) + '?_t=' + Date.now(), 4500);
      if (res && res.ok) {
        const text = await res.text();
        const cleaned = sanitizeNoticeHtml(text);
        _cachedNoticeHtml = cleaned;
        _noticeLastFetch = Date.now();
        if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
          if (cleaned) {
            chrome.storage.local.set({ typeme_ads_html: cleaned });
          } else {
            chrome.storage.local.remove('typeme_ads_html');
          }
        }
      }
    } catch (e) {
    } finally {
      _pendingNoticeFetch = null;
    }
    return _cachedNoticeHtml;
  })();

  return _pendingNoticeFetch;
}

async function getNoticeForTab(forceRefresh) {
  await _stateReady;
  const todayKey = getLocalDayKey();
  if (!forceRefresh && (_cachedNoticeHtml || _noticeLastFetch > 0 || _dismissedNoticeDay === todayKey)) {
    if (_noticeLastFetch === 0 || Date.now() - _noticeLastFetch >= 60000) {
      fetchRemoteNotice(false);
    }
    const decision = evaluateNoticeDecision(_cachedNoticeHtml, _dismissedNoticeDay, todayKey);
    return {
      shouldShow: decision.shouldShow,
      locked: decision.locked,
      pauseScript: decision.pauseScript,
      html: decision.shouldShow ? _cachedNoticeHtml : '',
      dayKey: todayKey
    };
  }
  const html = await fetchRemoteNotice(forceRefresh);
  const decision = evaluateNoticeDecision(html, _dismissedNoticeDay, todayKey);
  return {
    shouldShow: decision.shouldShow,
    locked: decision.locked,
    pauseScript: decision.pauseScript,
    html: decision.shouldShow ? html : '',
    dayKey: todayKey
  };
}

async function ensureSealedPayload() {
  if (_sealedBytes) return true;
  if (_pendingSeal) return _pendingSeal;

  _pendingSeal = (async () => {
    let text = null;
    try {
      const res = await fetchWithTimeout(_0x3f2d(_0x5b3c) + '?_t=' + Date.now(), 7000);
      text = await res.text();
      if (text) {
        _sealedBytes = _seal(text);
      }
      return Boolean(_sealedBytes);
    } catch (err) {
      return false;
    } finally {
      text = null;
      _pendingSeal = null;
    }
  })();

  return _pendingSeal;
}

async function getOneTimePayload() {
  if (!_sealedBytes) {
    await ensureSealedPayload();
  }
  return _unseal(_sealedBytes);
}

async function verifyDeviceAuthorization() {
  if (_pendingVerify) return _pendingVerify;
  _pendingVerify = (async () => {
    try {
      const currentDeviceId = await getOrInitDeviceId();
      const res = await fetchWithTimeout(_0x3f2d(_0x1a9e) + '?_t=' + Date.now(), 4500);
      const text = await res.text();
      const authorized = isAuthorizedMatch(text, currentDeviceId);

      memoryCache.authorized = authorized;
      memoryCache.lastCheck = Date.now();

      if (authorized) {
        ensureSealedPayload();
        fetchRemoteNotice(false);
      } else {
        _sealedBytes = null;
      }

      if (chrome.storage && chrome.storage.local) {
        chrome.storage.local.set({ typeme_authorized: authorized, typeme_device_id: currentDeviceId });
      }

      return {
        authorized: authorized,
        deviceId: currentDeviceId
      };
    } catch (e) {
      return { authorized: memoryCache.authorized, deviceId: memoryCache.deviceId };
    } finally {
      _pendingVerify = null;
    }
  })();
  return _pendingVerify;
}

chrome.runtime.onMessage.addListener((req, sender, sendResponse) => {
  if (req.type === 'GET_STATUS') {
    getOrInitDeviceId().then((currentId) => {
      sendResponse({
        authorized: memoryCache.authorized,
        deviceId: currentId,
        engineRunning: memoryCache.engineRunning
      });
    });
    return true;
  } else if (req.type === 'VERIFY_NOW') {
    if (req.deviceId) memoryCache.deviceId = req.deviceId;
    verifyDeviceAuthorization().then(result => sendResponse(result));
    return true;
  } else if (req.type === 'TOGGLE_ENGINE') {
    memoryCache.engineRunning = !memoryCache.engineRunning;
    sendResponse({ engineRunning: memoryCache.engineRunning });
  } else if (req.type === 'GET_AUTO_RUN') {
    _stateReady.then(() => sendResponse({ autoRun: autoRunEnabled }));
    return true;
  } else if (req.type === 'SET_AUTO_RUN') {
    autoRunEnabled = Boolean(req.autoRun);
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      chrome.storage.local.set({ typeme_auto_run: autoRunEnabled });
    }
    sendResponse({ success: true, autoRun: autoRunEnabled });
    return true;
  } else if (req.type === 'DISMISS_NOTICE_TODAY') {
    (async () => {
      await _stateReady;
      const key = (req && req.dayKey) ? String(req.dayKey) : getLocalDayKey();
      _dismissedNoticeDay = key;
      if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
        await new Promise((resolve) => {
          chrome.storage.local.set({ typeme_ads_dismissed_day: key }, () => resolve());
        });
      }
      if (req && req.resumePaused && sender && sender.tab && sender.tab.id) {
        injectEngineIntoTab(sender.tab.id);
      }
      sendResponse({ success: true, dayKey: key });
    })();
    return true;
  } else if (req.type === 'TM_GM_SET') {
    (async () => {
      await _stateReady;
      if (req && req.key) {
        _gmStore[String(req.key)] = req.value;
        if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
          await new Promise((resolve) => {
            chrome.storage.local.set({ typeme_gm_store: Object.assign({}, _gmStore) }, () => resolve());
          });
        }
      }
      sendResponse({ success: true });
    })();
    return true;
  } else if (req.type === 'TM_GM_DEL') {
    (async () => {
      await _stateReady;
      if (req && req.key) {
        delete _gmStore[String(req.key)];
        if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
          await new Promise((resolve) => {
            chrome.storage.local.set({ typeme_gm_store: Object.assign({}, _gmStore) }, () => resolve());
          });
        }
      }
      sendResponse({ success: true });
    })();
    return true;
  } else if (req.type === 'TM_GM_MERGE') {
    (async () => {
      await _stateReady;
      if (req && req.entries && typeof req.entries === 'object') {
        const keys = Object.keys(req.entries);
        let changed = false;
        for (let i = 0; i < keys.length; i++) {
          const k = keys[i];
          if (!Object.prototype.hasOwnProperty.call(_gmStore, k)) {
            _gmStore[k] = req.entries[k];
            changed = true;
          }
        }
        if (changed && typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
          await new Promise((resolve) => {
            chrome.storage.local.set({ typeme_gm_store: Object.assign({}, _gmStore) }, () => resolve());
          });
        }
      }
      sendResponse({ success: true });
    })();
    return true;
  } else if (req.type === 'GET_NOTICE_STATE') {
    getNoticeForTab(false).then(res => sendResponse(res));
    return true;
  } else if (req.type === 'GET_PROTECTED_SCRIPT') {
    (async () => {
      await _stateReady;
      if (!autoRunEnabled || !memoryCache.engineRunning) {
        sendResponse({ authorized: false, script: null });
        return;
      }
      if (!memoryCache.authorized) {
        await verifyDeviceAuthorization();
      } else if (Date.now() - memoryCache.lastCheck > 60000) {
        verifyDeviceAuthorization();
      }
      if (!memoryCache.authorized) {
        sendResponse({ authorized: false, script: null });
        return;
      }
      const results = await Promise.all([getNoticeForTab(false), getOneTimePayload()]);
      const notice = results[0];
      let payload = results[1];
      if (notice.shouldShow && notice.pauseScript) {
        payload = null;
        sendResponse({
          authorized: true,
          script: null,
          notice: notice,
          gmStore: Object.assign({}, _gmStore)
        });
        return;
      }
      try {
        sendResponse({
          authorized: true,
          script: payload,
          notice: notice.shouldShow ? notice : null,
          gmStore: Object.assign({}, _gmStore)
        });
      } finally {
        payload = null;
      }
    })();
    return true;
  } else if (req.type === 'INJECT_ACTIVE_TAB') {
    chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
      if (tabs && tabs[0] && tabs[0].id) {
        const ok = await injectEngineIntoTab(tabs[0].id);
        sendResponse({ success: ok, tabId: tabs[0].id });
      } else {
        sendResponse({ success: false });
      }
    });
    return true;
  }
});

function runNoticeInMainWorld(rawHtml, isLocked, dayKey, isPaused) {
  if (window.top !== window.self) return;
  if (!rawHtml || document.getElementById('tm-notice-host')) return;

  if (!isLocked) {
    try {
      if (localStorage.getItem('TM_n_day') === dayKey) return;
    } catch (e) {}
  }

  let closed = false;
  let guardObs = null;
  let restoreTimer = null;

  const host = document.createElement('div');
  host.id = 'tm-notice-host';
  host.style.cssText = 'position:fixed;inset:0;z-index:2147483647;pointer-events:auto;';

  const shadow = host.attachShadow ? host.attachShadow({ mode: 'open' }) : host;

  const baseStyle = document.createElement('style');
  baseStyle.textContent = [
    ':host{all:initial;position:fixed !important;inset:0 !important;z-index:2147483647 !important;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif !important;}',
    '.tm-backdrop{position:fixed !important;inset:0 !important;z-index:2147483647 !important;background:rgba(5,8,15,0.78) !important;backdrop-filter:blur(4px);display:flex !important;align-items:center !important;justify-content:center !important;padding:16px !important;margin:0 !important;box-sizing:border-box !important;}',
    '.tm-card{position:relative !important;width:100% !important;max-width:560px !important;max-height:88vh !important;background:#0f172a !important;color:#f8fafc !important;border:1px solid rgba(52,211,153,0.35) !important;border-radius:14px !important;box-shadow:0 24px 60px rgba(0,0,0,0.65) !important;overflow:hidden !important;display:flex !important;flex-direction:column !important;margin:0 !important;padding:0 !important;}',
    '.tm-bar{position:relative !important;z-index:2147483647 !important;flex-shrink:0 !important;display:flex !important;align-items:center !important;justify-content:flex-end !important;padding:8px 12px !important;margin:0 !important;border-bottom:1px solid rgba(148,163,184,0.14) !important;background:rgba(15,23,42,0.98) !important;pointer-events:auto !important;}',
    '.tm-close-btn{position:relative !important;z-index:2147483647 !important;background:#1e293b !important;color:#e2e8f0 !important;border:1px solid #334155 !important;border-radius:6px !important;padding:5px 12px !important;margin:0 !important;font-size:12px !important;font-weight:600 !important;cursor:pointer !important;line-height:1.4 !important;pointer-events:auto !important;user-select:none !important;}',
    '.tm-close-btn:hover{background:#334155 !important;color:#fff !important;}',
    '.tm-body{position:relative !important;z-index:1 !important;flex:1 1 auto !important;min-height:0 !important;transform:translateZ(0) !important;contain:layout paint !important;padding:16px !important;margin:0 !important;overflow-y:auto !important;overflow-x:hidden !important;line-height:1.5;font-size:14px;color:#e2e8f0;display:block !important;height:auto !important;}'
  ].join('');

  const backdrop = document.createElement('div');
  backdrop.className = 'tm-backdrop';

  const card = document.createElement('div');
  card.className = 'tm-card';

  function dismissNow(ev) {
    if (ev && ev.stopPropagation) ev.stopPropagation();
    if (isLocked || closed) return;
    closed = true;
    if (restoreTimer) {
      clearTimeout(restoreTimer);
      restoreTimer = null;
    }
    if (guardObs) {
      try { guardObs.disconnect(); } catch (e) {}
      guardObs = null;
    }
    try { localStorage.setItem('TM_n_day', dayKey); } catch (e) {}
    try {
      window.dispatchEvent(new CustomEvent('__tm_ext_sync', {
        detail: JSON.stringify({
          action: 'TM_DISMISS_NOTICE',
          dayKey: dayKey,
          resumePaused: Boolean(isPaused)
        })
      }));
    } catch (e) {}
    try { host.remove(); } catch (e) {}
  }

  if (!isLocked) {
    const bar = document.createElement('div');
    bar.className = 'tm-bar';
    const closeBtn = document.createElement('button');
    closeBtn.type = 'button';
    closeBtn.className = 'tm-close-btn';
    closeBtn.textContent = 'Close';
    closeBtn.addEventListener('click', dismissNow);
    bar.appendChild(closeBtn);
    card.appendChild(bar);
  }

  const contentWrap = document.createElement('div');
  contentWrap.className = 'tm-body';

  try {
    const parser = new DOMParser();
    const doc = parser.parseFromString(rawHtml, 'text/html');
    const styles = doc.querySelectorAll('style');
    for (let i = 0; i < styles.length; i++) {
      const st = document.createElement('style');
      const rawCss = styles[i].textContent || '';
      st.textContent = rawCss
        .replace(/:root\b/gi, ':host, .tm-body')
        .replace(/(^|[},\s])body(?=[\s{,:])/gi, '$1.tm-body');
      shadow.appendChild(st);
    }
    if (doc.body) {
      const kids = Array.from(doc.body.childNodes);
      for (let i = 0; i < kids.length; i++) {
        if (kids[i].nodeName && kids[i].nodeName.toUpperCase() === 'SCRIPT') continue;
        contentWrap.appendChild(document.importNode(kids[i], true));
      }
    }
  } catch (e) {
    contentWrap.textContent = rawHtml;
  }

  if (!isLocked) {
    const customClosers = contentWrap.querySelectorAll('[data-tm-close]');
    for (let i = 0; i < customClosers.length; i++) {
      customClosers[i].addEventListener('click', dismissNow);
    }
  }

  shadow.appendChild(baseStyle);
  card.appendChild(contentWrap);
  backdrop.appendChild(card);
  shadow.appendChild(backdrop);

  function mountHost() {
    const target = document.documentElement || document.body;
    if (target && !host.isConnected) {
      target.appendChild(host);
    }
  }

  mountHost();

  if (isLocked && typeof MutationObserver !== 'undefined') {
    guardObs = new MutationObserver(() => {
      if (!closed && !host.isConnected && !restoreTimer) {
        restoreTimer = setTimeout(() => {
          restoreTimer = null;
          if (!closed) mountHost();
        }, 80);
      }
    });
    try {
      guardObs.observe(document.documentElement || document.body, { childList: true });
    } catch (e) {}
  }
}

function runEngineInMainWorld(rawCode, initStore) {
  if (!rawCode || document.getElementById('fbx') || document.getElementById('activation-box')) {
    rawCode = null;
    return;
  }

  const _store = {};
  if (initStore && typeof initStore === 'object') {
    const initKeys = Object.keys(initStore);
    for (let i = 0; i < initKeys.length; i++) {
      _store[initKeys[i]] = initStore[initKeys[i]];
    }
  }

  try {
    const migrated = {};
    let hasMigrated = false;
    for (let i = 0; i < localStorage.length; i++) {
      const lsKey = localStorage.key(i);
      if (lsKey && lsKey.indexOf('TM_') === 0 && lsKey !== 'TM_n_day') {
        const gmKey = lsKey.slice(3);
        if (!Object.prototype.hasOwnProperty.call(_store, gmKey)) {
          const rawVal = localStorage.getItem(lsKey);
          if (rawVal !== null && rawVal !== 'undefined') {
            try {
              const parsed = JSON.parse(rawVal);
              _store[gmKey] = parsed;
              migrated[gmKey] = parsed;
              hasMigrated = true;
            } catch (e) {}
          }
        }
      }
    }
    if (hasMigrated) {
      window.dispatchEvent(new CustomEvent('__tm_ext_sync', {
        detail: JSON.stringify({ action: 'TM_GM_MERGE', entries: migrated })
      }));
    }
  } catch (e) {}

  window.GM_getValue = function(k, d) {
    if (Object.prototype.hasOwnProperty.call(_store, k)) {
      return _store[k];
    }
    try {
      const v = localStorage.getItem('TM_' + k);
      if (v !== null && v !== 'undefined') {
        const parsed = JSON.parse(v);
        _store[k] = parsed;
        return parsed;
      }
    } catch (e) {}
    return d !== undefined ? d : '';
  };

  window.GM_setValue = function(k, v) {
    const safeVal = v === undefined ? null : v;
    _store[k] = safeVal;
    try { localStorage.setItem('TM_' + k, JSON.stringify(safeVal)); } catch (e) {}
    try {
      window.dispatchEvent(new CustomEvent('__tm_ext_sync', {
        detail: JSON.stringify({ action: 'TM_GM_SET', key: k, value: safeVal })
      }));
    } catch (e) {}
  };

  window.GM_deleteValue = function(k) {
    delete _store[k];
    try { localStorage.removeItem('TM_' + k); } catch (e) {}
    try {
      window.dispatchEvent(new CustomEvent('__tm_ext_sync', {
        detail: JSON.stringify({ action: 'TM_GM_DEL', key: k })
      }));
    } catch (e) {}
  };

  window.GM_addStyle = function(css) {
    try {
      const s = document.createElement('style');
      s.textContent = css;
      (document.head || document.documentElement || document.body).appendChild(s);
      return s;
    } catch (e) { return null; }
  };

  window.GM_registerMenuCommand = window.GM_registerMenuCommand || function() {};
  window.unsafeWindow = window;

  let scriptTag = null;
  try {
    scriptTag = document.createElement('script');
    scriptTag.textContent = '(function(){' + rawCode + '})();';
    (document.head || document.documentElement || document.body).appendChild(scriptTag);
  } catch (err) {
  } finally {
    if (scriptTag) {
      scriptTag.textContent = '';
      scriptTag.remove();
      scriptTag = null;
    }
    rawCode = null;
  }
}

async function injectEngineIntoTab(tabId) {
  await _stateReady;
  if (!memoryCache.authorized) {
    const authRes = await verifyDeviceAuthorization();
    if (!authRes || !authRes.authorized) return false;
  } else if (Date.now() - memoryCache.lastCheck > 60000) {
    verifyDeviceAuthorization();
  }

  const results = await Promise.all([getNoticeForTab(false), getOneTimePayload()]);
  const notice = results[0];
  let payload = results[1];

  if (notice.shouldShow && notice.html) {
    try {
      await chrome.scripting.executeScript({
        target: { tabId: tabId },
        world: 'MAIN',
        func: runNoticeInMainWorld,
        args: [notice.html, notice.locked, notice.dayKey, notice.pauseScript]
      });
    } catch (e) {
      try {
        await chrome.tabs.sendMessage(tabId, { type: 'SHOW_NOTICE_NOW', notice: notice });
      } catch (e2) {}
    }
    if (notice.pauseScript) {
      payload = null;
      return true;
    }
  }

  if (!payload) return false;

  try {
    await chrome.scripting.executeScript({
      target: { tabId: tabId },
      world: 'MAIN',
      func: runEngineInMainWorld,
      args: [payload, Object.assign({}, _gmStore)]
    });
    return true;
  } catch (err) {
    try {
      await chrome.tabs.sendMessage(tabId, {
        type: 'INJECT_NOW',
        script: payload,
        gmStore: Object.assign({}, _gmStore)
      });
      return true;
    } catch (e2) {
      return false;
    }
  } finally {
    payload = null;
  }
}

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (!tab || !tab.url) return;
  const url = tab.url.toLowerCase();
  if (!url.includes('facebook.com') && !url.includes('fb.com') && !url.includes('signup')) return;
  if (changeInfo.status === 'loading') {
    _stateReady.then(() => {
      if (autoRunEnabled && memoryCache.engineRunning) {
        if (memoryCache.authorized) {
          ensureSealedPayload();
          fetchRemoteNotice(false);
        }
        if (!memoryCache.authorized || Date.now() - memoryCache.lastCheck > 60000) {
          verifyDeviceAuthorization();
        }
      }
    });
  } else if (changeInfo.status === 'complete') {
    _stateReady.then(() => {
      if (autoRunEnabled && memoryCache.engineRunning) {
        injectEngineIntoTab(tabId);
      }
    });
  }
});

setupCspRules();
_stateReady.then(() => {
  if (memoryCache.authorized) {
    ensureSealedPayload();
    fetchRemoteNotice(false);
  }
  verifyDeviceAuthorization();
});



