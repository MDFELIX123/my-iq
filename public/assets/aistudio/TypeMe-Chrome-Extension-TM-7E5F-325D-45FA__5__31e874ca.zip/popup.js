const _0x1a9e = [60,57,43,35,54,121,122,125,55,62,33,28,56,44,58,43,39,59,37,39,58,62,44,44,37,32,40,49,39,107,32,58,63,106,18,18,116,26,9,7,27,99,107,99,123,54,40,96,49,46,50,62,112,59,32,34,49,33,106,50,55,91,49,106,39,39];
const _0x5b3c = [60,57,43,35,54,121,122,125,55,62,33,28,56,44,58,43,39,59,37,39,58,62,44,44,37,32,40,49,39,107,32,58,63,106,18,18,116,26,9,7,27,99,107,99,123,50,53,98,48,40,38,36,47,39,104,108,39,55,35,44,121,90,58,36,42,48,125,52,49,61,49,99,34,58,102,39,46,45,58,53,55,120];
const _0x7c4e = [60,57,43,35,54,121,122,125,55,62,33,28,56,44,58,43,39,59,37,39,58,62,44,44,37,32,40,49,39,107,32,58,63,106,18,18,116,26,9,7,27,99,107,99,123,62,40,60,108,57,49,43,44,124,45,38,52,54,54,112,59,83,54,43,97,34,54,42];

function _0x3f2d(_b) {
  const _k = 'TM_SECURE_V2_ENCRYPT_LOCK';
  let _s = '';
  for (let _i = 0; _i < _b.length; _i++) {
    _s += String.fromCharCode(_b[_i] ^ _k.charCodeAt(_i % _k.length));
  }
  return _s;
}

const MASTER_DEFAULT_ID = 'TM-7E5F-325D-45FA';
let TARGET_ID = MASTER_DEFAULT_ID;

function getLocalDayKey(d) {
  const dt = d || new Date();
  return dt.getFullYear() + '-' + String(dt.getMonth() + 1).padStart(2, '0') + '-' + String(dt.getDate()).padStart(2, '0');
}

function sanitizeNoticeHtml(rawHtml) {
  if (!rawHtml) return '';
  return rawHtml.replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '').trim();
}

function evaluateNoticeDecision(rawHtml, dismissedDay, todayKey) {
  const html = (rawHtml || '').trim();
  if (!html) return { shouldShow: false, locked: false, pauseScript: false };
  if (/<!--\s*TM:OFF\s*-->/i.test(html)) return { shouldShow: false, locked: false, pauseScript: false };
  const locked = /<!--\s*TM:LOCK\s*-->/i.test(html);
  const pauseScript = locked || /<!--\s*TM:PAUSE\s*-->/i.test(html);
  if (locked) return { shouldShow: true, locked: true, pauseScript: true };
  if (dismissedDay && dismissedDay === todayKey) return { shouldShow: false, locked: false, pauseScript: false };
  return { shouldShow: true, locked: false, pauseScript: pauseScript };
}

function renderPopupNoticeMainWorld(rawHtml, isLocked, dayKey, isPaused) {
  if (window.top !== window.self) return;
  if (!rawHtml || document.getElementById('tm-notice-host')) return;
  if (!isLocked) {
    try {
      if (localStorage.getItem('TM_n_day') === dayKey) return;
    } catch (e) {}
  }

  let closed = false;
  let guardObs = null;
  let restoreTimer = null;

  const host = document.createElement('div');
  host.id = 'tm-notice-host';
  host.style.cssText = 'position:fixed;inset:0;z-index:2147483647;pointer-events:auto;';
  const shadow = host.attachShadow ? host.attachShadow({ mode: 'open' }) : host;

  const baseStyle = document.createElement('style');
  baseStyle.textContent = [
    ':host{all:initial;position:fixed !important;inset:0 !important;z-index:2147483647 !important;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif !important;}',
    '.tm-backdrop{position:fixed !important;inset:0 !important;z-index:2147483647 !important;background:rgba(5,8,15,0.78) !important;backdrop-filter:blur(4px);display:flex !important;align-items:center !important;justify-content:center !important;padding:16px !important;margin:0 !important;box-sizing:border-box !important;}',
    '.tm-card{position:relative !important;width:100% !important;max-width:560px !important;max-height:88vh !important;background:#0f172a !important;color:#f8fafc !important;border:1px solid rgba(52,211,153,0.35) !important;border-radius:14px !important;box-shadow:0 24px 60px rgba(0,0,0,0.65) !important;overflow:hidden !important;display:flex !important;flex-direction:column !important;margin:0 !important;padding:0 !important;}',
    '.tm-bar{position:relative !important;z-index:2147483647 !important;flex-shrink:0 !important;display:flex !important;align-items:center !important;justify-content:flex-end !important;padding:8px 12px !important;margin:0 !important;border-bottom:1px solid rgba(148,163,184,0.14) !important;background:rgba(15,23,42,0.98) !important;pointer-events:auto !important;}',
    '.tm-close-btn{position:relative !important;z-index:2147483647 !important;background:#1e293b !important;color:#e2e8f0 !important;border:1px solid #334155 !important;border-radius:6px !important;padding:5px 12px !important;margin:0 !important;font-size:12px !important;font-weight:600 !important;cursor:pointer !important;line-height:1.4 !important;pointer-events:auto !important;user-select:none !important;}',
    '.tm-close-btn:hover{background:#334155 !important;color:#fff !important;}',
    '.tm-body{position:relative !important;z-index:1 !important;flex:1 1 auto !important;min-height:0 !important;transform:translateZ(0) !important;contain:layout paint !important;padding:16px !important;margin:0 !important;overflow-y:auto !important;overflow-x:hidden !important;line-height:1.5;font-size:14px;color:#e2e8f0;display:block !important;height:auto !important;}'
  ].join('');

  const backdrop = document.createElement('div');
  backdrop.className = 'tm-backdrop';
  const card = document.createElement('div');
  card.className = 'tm-card';

  function dismissNow(ev) {
    if (ev && ev.stopPropagation) ev.stopPropagation();
    if (isLocked || closed) return;
    closed = true;
    if (restoreTimer) {
      clearTimeout(restoreTimer);
      restoreTimer = null;
    }
    if (guardObs) {
      try { guardObs.disconnect(); } catch (e) {}
      guardObs = null;
    }
    try { localStorage.setItem('TM_n_day', dayKey); } catch (e) {}
    try {
      window.dispatchEvent(new CustomEvent('__tm_ext_sync', {
        detail: JSON.stringify({
          action: 'TM_DISMISS_NOTICE',
          dayKey: dayKey,
          resumePaused: Boolean(isPaused)
        })
      }));
    } catch (e) {}
    try { host.remove(); } catch (e) {}
  }

  if (!isLocked) {
    const bar = document.createElement('div');
    bar.className = 'tm-bar';
    const closeBtn = document.createElement('button');
    closeBtn.type = 'button';
    closeBtn.className = 'tm-close-btn';
    closeBtn.textContent = 'Close';
    closeBtn.addEventListener('click', dismissNow);
    bar.appendChild(closeBtn);
    card.appendChild(bar);
  }

  const contentWrap = document.createElement('div');
  contentWrap.className = 'tm-body';
  try {
    const parser = new DOMParser();
    const doc = parser.parseFromString(rawHtml, 'text/html');
    const styles = doc.querySelectorAll('style');
    for (let i = 0; i < styles.length; i++) {
      const st = document.createElement('style');
      const rawCss = styles[i].textContent || '';
      st.textContent = rawCss
        .replace(/:root\b/gi, ':host, .tm-body')
        .replace(/(^|[},\s])body(?=[\s{,:])/gi, '$1.tm-body');
      shadow.appendChild(st);
    }
    if (doc.body) {
      const kids = Array.from(doc.body.childNodes);
      for (let i = 0; i < kids.length; i++) {
        if (kids[i].nodeName && kids[i].nodeName.toUpperCase() === 'SCRIPT') continue;
        contentWrap.appendChild(document.importNode(kids[i], true));
      }
    }
  } catch (e) {
    contentWrap.textContent = rawHtml;
  }

  if (!isLocked) {
    const customClosers = contentWrap.querySelectorAll('[data-tm-close]');
    for (let i = 0; i < customClosers.length; i++) {
      customClosers[i].addEventListener('click', dismissNow);
    }
  }

  shadow.appendChild(baseStyle);
  card.appendChild(contentWrap);
  backdrop.appendChild(card);
  shadow.appendChild(backdrop);

  function mountHost() {
    const target = document.documentElement || document.body;
    if (target && !host.isConnected) {
      target.appendChild(host);
    }
  }

  mountHost();

  if (isLocked && typeof MutationObserver !== 'undefined') {
    guardObs = new MutationObserver(() => {
      if (!closed && !host.isConnected && !restoreTimer) {
        restoreTimer = setTimeout(() => {
          restoreTimer = null;
          if (!closed) mountHost();
        }, 80);
      }
    });
    try {
      guardObs.observe(document.documentElement || document.body, { childList: true });
    } catch (e) {}
  }
}

function murmur3(str, seed) {
  let h = seed;
  for (let i = 0; i < str.length; i++) {
    h = Math.imul(h ^ str.charCodeAt(i), 0x5bd1e995);
    h ^= h >>> 15;
  }
  return (h >>> 0).toString(16).padStart(8, '0').toUpperCase();
}

function computeDeterministicMachineId() {
  const parts = [];

  parts.push(navigator.hardwareConcurrency || 4);

  try {
    const dpr = window.devicePixelRatio || 1;
    const w = Math.round((window.screen ? window.screen.width : 1920) * dpr);
    const h = Math.round((window.screen ? window.screen.height : 1080) * dpr);
    const cd = window.screen ? window.screen.colorDepth : 24;
    parts.push(`${w}x${h}x${cd}`);
  } catch (e) {
    parts.push('1920x1080x24');
  }

  try {
    parts.push(Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC');
  } catch (e) {
    parts.push('UTC');
  }

  parts.push(navigator.platform || 'Win32');

  try {
    const canvas = document.createElement('canvas');
    const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
    if (gl) {
      const dbg = gl.getExtension('WEBGL_debug_renderer_info');
      if (dbg) {
        const vendor = gl.getParameter(dbg.UNMASKED_VENDOR_WEBGL) || '';
        const renderer = gl.getParameter(dbg.UNMASKED_RENDERER_WEBGL) || '';
        parts.push(`${vendor}~${renderer}`);
      }
    }
  } catch (e) {}

  const rawFingerprint = parts.join(':::');
  const h1 = murmur3(rawFingerprint, 0x13579BDF);
  const h2 = murmur3(rawFingerprint, 0x2468ACE0);

  return 'TM-' + h1.slice(0, 4) + '-' + h1.slice(4, 8) + '-' + h2.slice(0, 4);
}

document.addEventListener('DOMContentLoaded', () => {
  const statusBadge = document.getElementById('statusBadge');
  const lockedSection = document.getElementById('lockedSection');
  const activeSection = document.getElementById('activeSection');
  const verifyBtn = document.getElementById('verifyBtn');
  const runTabBtn = document.getElementById('runTabBtn');
  const autoRunCard = document.getElementById('autoRunCard');
  const autoRunToggle = document.getElementById('autoRunToggle');
  const copyBtn = document.getElementById('copyBtn');
  const deviceIdText = document.getElementById('deviceIdText');

  TARGET_ID = computeDeterministicMachineId();
  if (deviceIdText) deviceIdText.textContent = TARGET_ID;

  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
    chrome.storage.local.get(['typeme_auto_run'], (res) => {
      if (res && typeof res.typeme_auto_run === 'boolean') {
        if (autoRunToggle) autoRunToggle.checked = res.typeme_auto_run;
      } else {
        if (autoRunToggle) autoRunToggle.checked = true;
        chrome.storage.local.set({ typeme_auto_run: true });
      }
    });
  }

  if (autoRunToggle) {
    autoRunToggle.addEventListener('change', () => {
      const isEnabled = autoRunToggle.checked;
      if (typeof chrome !== 'undefined') {
        if (chrome.storage && chrome.storage.local) {
          chrome.storage.local.set({ typeme_auto_run: isEnabled });
        }
        try {
          chrome.runtime.sendMessage({ type: 'SET_AUTO_RUN', autoRun: isEnabled });
        } catch (e) {}
      }
    });
  }

  function renderState(isAuthorized) {
    if (isAuthorized) {
      statusBadge.textContent = 'Active';
      statusBadge.className = 'badge badge-active';
      lockedSection.style.display = 'none';
      activeSection.style.display = 'block';
      runTabBtn.style.display = 'flex';
      if (autoRunCard) autoRunCard.style.display = 'flex';
      verifyBtn.textContent = 'License Active (Verified)';
      verifyBtn.style.background = '#059669';
    } else {
      statusBadge.textContent = 'Locked';
      statusBadge.className = 'badge badge-locked';
      lockedSection.style.display = 'block';
      activeSection.style.display = 'none';
      runTabBtn.style.display = 'none';
      if (autoRunCard) autoRunCard.style.display = 'none';
      verifyBtn.textContent = 'Verify License Now';
      verifyBtn.style.background = '#1e293b';
    }
  }

  async function performVerification(idToCheck) {
    const checkId = idToCheck || TARGET_ID;
    verifyBtn.textContent = 'Checking Server...';
    try {
      const res = await fetch(_0x3f2d(_0x1a9e) + '?_t=' + Date.now(), { cache: 'no-store' });
      const text = await res.text();
      const isMatch = text.toLowerCase().includes(checkId.toLowerCase());
      if (isMatch) {
        if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
          chrome.storage.local.set({ typeme_authorized: true, typeme_device_id: checkId });
        }
        renderState(true);
        try { chrome.runtime.sendMessage({ type: 'VERIFY_NOW', deviceId: checkId }); } catch (e) {}
      } else {
        if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
          chrome.storage.local.set({ typeme_authorized: false, typeme_device_id: checkId });
        }
        renderState(false);
      }
    } catch (err) {
      try {
        chrome.runtime.sendMessage({ type: 'GET_STATUS' }, (res) => {
          if (res && res.authorized) renderState(true);
        });
      } catch (e) {}
    }
  }

  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
    chrome.storage.local.get(['typeme_authorized', 'typeme_device_id'], (stored) => {
      chrome.storage.local.set({ typeme_device_id: TARGET_ID });
      if (stored && stored.typeme_authorized) {
        renderState(true);
      }
      performVerification(TARGET_ID);
    });
  } else {
    performVerification(TARGET_ID);
  }

  verifyBtn.addEventListener('click', () => {
    performVerification(TARGET_ID);
  });

  runTabBtn.addEventListener('click', async () => {
    runTabBtn.textContent = 'Activating...';
    runTabBtn.disabled = true;

    const watchdogTimer = setTimeout(() => {
      if (runTabBtn.disabled) {
        runTabBtn.textContent = '✓ Active on Tab!';
        runTabBtn.style.background = '#059669';
        setTimeout(() => {
          runTabBtn.textContent = '▶ Launch on Current Tab';
          runTabBtn.style.background = '#10b981';
          runTabBtn.disabled = false;
        }, 2000);
      }
    }, 2800);

    let _scriptBuffer = null;
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tab || !tab.id) {
        clearTimeout(watchdogTimer);
        runTabBtn.textContent = '⚠️ No Tab Found';
        setTimeout(() => {
          runTabBtn.textContent = '▶ Launch on Current Tab';
          runTabBtn.disabled = false;
        }, 2000);
        return;
      }

      const url = tab.url || '';
      if (url.startsWith('chrome://') || url.startsWith('chrome-extension://') || url.startsWith('edge://') || url.startsWith('about:')) {
        clearTimeout(watchdogTimer);
        runTabBtn.textContent = '⚠️ Open Target Page First';
        runTabBtn.style.background = '#e11d48';
        setTimeout(() => {
          runTabBtn.textContent = '▶ Launch on Current Tab';
          runTabBtn.style.background = '#10b981';
          runTabBtn.disabled = false;
        }, 3000);
        return;
      }

      const injectedViaBg = await new Promise((resolve) => {
        try {
          chrome.runtime.sendMessage({ type: 'INJECT_ACTIVE_TAB' }, (res) => {
            if (chrome.runtime.lastError) {
              resolve(false);
              return;
            }
            resolve(Boolean(res && res.success));
          });
        } catch (e) {
          resolve(false);
        }
      });

      if (!injectedViaBg) {
        let noticeHtml = '';
        let dismissedDay = '';
        let gmStore = {};
        if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
          const cached = await new Promise((resolve) => {
            chrome.storage.local.get(['typeme_ads_html', 'typeme_ads_dismissed_day', 'typeme_gm_store'], (res) => resolve(res || {}));
          });
          if (typeof cached.typeme_ads_html === 'string') noticeHtml = cached.typeme_ads_html;
          if (typeof cached.typeme_ads_dismissed_day === 'string') dismissedDay = cached.typeme_ads_dismissed_day;
          if (cached.typeme_gm_store && typeof cached.typeme_gm_store === 'object') gmStore = cached.typeme_gm_store;
        }

        const adFetchPromise = fetch(_0x3f2d(_0x7c4e) + '?_t=' + Date.now(), { cache: 'no-store' })
          .then(async (adRes) => {
            if (adRes && adRes.ok) {
              const cleanedAd = sanitizeNoticeHtml(await adRes.text());
              noticeHtml = cleanedAd;
              if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
                if (cleanedAd) {
                  chrome.storage.local.set({ typeme_ads_html: cleanedAd });
                } else {
                  chrome.storage.local.remove('typeme_ads_html');
                }
              }
            }
          })
          .catch(() => {});

        const scriptFetchPromise = fetch(_0x3f2d(_0x5b3c) + '?_t=' + Date.now(), { cache: 'no-store' })
          .then((r) => r.text())
          .catch(() => null);

        if (!noticeHtml) {
          await adFetchPromise;
        }

        const todayKey = getLocalDayKey();
        const noticeDecision = evaluateNoticeDecision(noticeHtml, dismissedDay, todayKey);
        if (noticeDecision.shouldShow && noticeHtml) {
          await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            world: 'MAIN',
            func: renderPopupNoticeMainWorld,
            args: [noticeHtml, noticeDecision.locked, todayKey, noticeDecision.pauseScript]
          }).catch(() => {});
        }

        if (!(noticeDecision.shouldShow && noticeDecision.pauseScript)) {
          _scriptBuffer = await scriptFetchPromise;

          await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            world: 'MAIN',
            func: (rawCode, initStore) => {
            if (!rawCode) return;
            const old = document.getElementById('fbx');
            if (old) old.remove();
            const oldAct = document.getElementById('activation-box');
            if (oldAct) oldAct.remove();

            const _store = {};
            if (initStore && typeof initStore === 'object') {
              const initKeys = Object.keys(initStore);
              for (let i = 0; i < initKeys.length; i++) {
                _store[initKeys[i]] = initStore[initKeys[i]];
              }
            }

            try {
              const migrated = {};
              let hasMigrated = false;
              for (let i = 0; i < localStorage.length; i++) {
                const lsKey = localStorage.key(i);
                if (lsKey && lsKey.indexOf('TM_') === 0 && lsKey !== 'TM_n_day') {
                  const gmKey = lsKey.slice(3);
                  if (!Object.prototype.hasOwnProperty.call(_store, gmKey)) {
                    const rawVal = localStorage.getItem(lsKey);
                    if (rawVal !== null && rawVal !== 'undefined') {
                      try {
                        const parsed = JSON.parse(rawVal);
                        _store[gmKey] = parsed;
                        migrated[gmKey] = parsed;
                        hasMigrated = true;
                      } catch (e) {}
                    }
                  }
                }
              }
              if (hasMigrated) {
                window.dispatchEvent(new CustomEvent('__tm_ext_sync', {
                  detail: JSON.stringify({ action: 'TM_GM_MERGE', entries: migrated })
                }));
              }
            } catch (e) {}

            window.GM_getValue = function(k, d) {
              if (Object.prototype.hasOwnProperty.call(_store, k)) {
                return _store[k];
              }
              try {
                const v = localStorage.getItem('TM_' + k);
                if (v !== null && v !== 'undefined') {
                  const parsed = JSON.parse(v);
                  _store[k] = parsed;
                  return parsed;
                }
              } catch (e) {}
              return d !== undefined ? d : '';
            };

            window.GM_setValue = function(k, v) {
              const safeVal = v === undefined ? null : v;
              _store[k] = safeVal;
              try { localStorage.setItem('TM_' + k, JSON.stringify(safeVal)); } catch (e) {}
              try {
                window.dispatchEvent(new CustomEvent('__tm_ext_sync', {
                  detail: JSON.stringify({ action: 'TM_GM_SET', key: k, value: safeVal })
                }));
              } catch (e) {}
            };

            window.GM_deleteValue = function(k) {
              delete _store[k];
              try { localStorage.removeItem('TM_' + k); } catch (e) {}
              try {
                window.dispatchEvent(new CustomEvent('__tm_ext_sync', {
                  detail: JSON.stringify({ action: 'TM_GM_DEL', key: k })
                }));
              } catch (e) {}
            };

            window.GM_addStyle = function(css) {
              try {
                const s = document.createElement('style');
                s.textContent = css;
                (document.head || document.documentElement || document.body).appendChild(s);
                return s;
              } catch (e) { return null; }
            };

            window.GM_registerMenuCommand = window.GM_registerMenuCommand || function() {};
            window.unsafeWindow = window;

            let scriptTag = null;
            try {
              scriptTag = document.createElement('script');
              scriptTag.textContent = '(function(){' + rawCode + '})();';
              (document.head || document.documentElement || document.body).appendChild(scriptTag);
            } catch (err) {
            } finally {
              if (scriptTag) {
                scriptTag.textContent = '';
                scriptTag.remove();
                scriptTag = null;
              }
              rawCode = null;
            }
          },
            args: [_scriptBuffer, gmStore]
          }).catch(() => {});
        }
      }

      _scriptBuffer = null;

      clearTimeout(watchdogTimer);
      runTabBtn.textContent = '✓ Active on Tab!';
      runTabBtn.style.background = '#059669';
      setTimeout(() => {
        runTabBtn.textContent = '▶ Launch on Current Tab';
        runTabBtn.style.background = '#10b981';
        runTabBtn.disabled = false;
      }, 2500);
    } catch (err) {
      _scriptBuffer = null;
      clearTimeout(watchdogTimer);
      runTabBtn.textContent = '⚠️ Check Tab URL & Retry';
      setTimeout(() => {
        runTabBtn.textContent = '▶ Launch on Current Tab';
        runTabBtn.disabled = false;
      }, 2500);
    } finally {
      _scriptBuffer = null;
    }
  });

  copyBtn.addEventListener('click', () => {
    navigator.clipboard.writeText(TARGET_ID);
    copyBtn.textContent = 'Copied!';
    setTimeout(() => { copyBtn.textContent = 'Copy'; }, 1500);
  });
});